#include<stdio.h>

main (){
    int a;
    int b;
    int c;
    int d;
    int e;


    printf("enter your vlaue of a :");
    scanf("%d",&a);

    printf("enter your vlaue of b :");
    scanf("%d",&b);

    printf("enter your vlaue of c :");
    scanf("%d",&c);

    printf("enter your vlaue of d :");
    scanf("%d",&d);

    e = (a+b) * (c-d);

    printf("your answer is : %d",e);

    


   


}