#include<stdio.h>

main (){
    int a;
    int b;
    int c;

    printf("Enter Value of a : ");
    scanf("%d",&a);


    printf("Enter Value of a : ");
    scanf("%d",&b);

  

    printf("%d",c=a+b);
}