#include<stdio.h>

main (){
    int time;
    int Distance​;
    int Velocity;


    printf("enter your time");
    scanf("%d",&time);

    printf("enter your Distance");
    scanf("%d",&Distance​);

    Velocity = time / Distance​;

    printf("Your Velocity is : %d",Velocity);


}