#include<stdio.h>

main (){
    int a;
    int b;
    int c;
    int d;

   printf("Enter Value Of a :");
   scanf("%d",&a);

    printf("Enter Value Of b :");
   scanf("%d",&b);


    printf("Enter Value Of c :");
   scanf("%d",&c);

    d = (a+b+c)/3;

    printf("%d",d);
}