#include<stdio.h>

main (){
    int a;
    int b;


    printf("Enter your Value : ");
    scanf("%d",&a);

    b = a*a;

    printf("Square of a Number is : %d",b);
}